cdef class placeholder():
    pass
